<?php
$con = mysqli_connect("localhost","root", "1234", "threaderz_store");
?>